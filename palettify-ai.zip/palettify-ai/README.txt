PALETTIFY-AI THEME — INSTALL
1. WordPress Admin → Appearance → Themes → Add New → Upload Theme → choose palettify-ai.zip → Install → Activate.
2. Appearance → Palettify Settings → paste your Groq API key (console.groq.com/keys) → Save.
3. Visit your homepage (generator is built in) or /palettify/ (dedicated page created on activation).
Languages: EN / FR / AR (RTL) / ES via the header dropdown. Language is remembered in a cookie.
