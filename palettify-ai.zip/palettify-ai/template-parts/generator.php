<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="pf-tool">
  <div class="pf-tool-head">
    <h2 class="pf-h2" data-i18n="tool_title">Design system generator</h2>
    <p class="pf-lead" data-i18n="tool_sub">Tell us about your website. We’ll craft three tailored directions.</p>
  </div>

  <form id="pf-form" class="pf-form pf-gcard pf-spot" novalidate>
    <div class="pf-field">
      <label for="pf-name" data-i18n="lbl_name">Website name</label>
      <input id="pf-name" name="name" type="text" maxlength="120" required data-i18n-ph="ph_name" placeholder="e.g. Luma Skincare">
    </div>
    <div class="pf-field">
      <label for="pf-industry" data-i18n="lbl_industry">Industry / niche</label>
      <input id="pf-industry" name="industry" type="text" list="pf-industries" maxlength="120" required data-i18n-ph="ph_industry" placeholder="e.g. Organic beauty">
      <datalist id="pf-industries">
        <option value="SaaS / Software"><option value="E-commerce / Fashion"><option value="Health &amp; Wellness"><option value="Finance / Fintech">
        <option value="Education / E-learning"><option value="Restaurant / Food"><option value="Real Estate"><option value="Travel &amp; Hospitality">
        <option value="Creative Agency / Portfolio"><option value="Non-profit"><option value="Gaming / Entertainment">
      </datalist>
    </div>
    <div class="pf-field pf-wide">
      <label for="pf-mood" data-i18n="lbl_mood">Target audience / mood</label>
      <input id="pf-mood" name="mood" type="text" maxlength="120" required data-i18n-ph="ph_mood" placeholder="e.g. Women 25–40, calm, trustworthy, natural">
    </div>
    <div class="pf-field">
      <label for="pf-stack" data-i18n="lbl_stack">Tech stack / CMS</label>
      <input id="pf-stack" name="stack" type="text" list="pf-stacks" maxlength="120" placeholder="WordPress">
      <datalist id="pf-stacks">
        <option value="WordPress"><option value="Shopify"><option value="Next.js + Tailwind"><option value="React"><option value="Webflow"><option value="Laravel"><option value="Vue / Nuxt"><option value="Plain HTML/CSS">
      </datalist>
    </div>
    <div class="pf-field">
      <label for="pf-country" data-i18n="lbl_country">Target country / region</label>
      <input id="pf-country" name="country" type="text" maxlength="120" data-i18n-ph="ph_country" placeholder="e.g. United Arab Emirates">
    </div>
    <div class="pf-form-foot pf-wide">
      <button type="submit" class="pf-btn pf-btn-lg" id="pf-submit"><span class="pf-btn-label" data-i18n="btn_generate">Generate 3 schemes</span></button>
      <p class="pf-error" id="pf-error" role="alert" hidden></p>
    </div>
  </form>

  <div id="pf-loading" class="pf-loading" hidden>
    <div class="pf-loader"><i></i><i></i><i></i></div>
    <p data-i18n="loading">Mixing colors and pairing fonts…</p>
  </div>
  <div id="pf-results" class="pf-results" aria-live="polite"></div>
</div>

<div class="pf-modal" id="pf-modal" hidden>
  <div class="pf-modal-card pf-gcard">
    <header>
      <h3 data-i18n="export_title">Export design system</h3>
      <button type="button" class="pf-x" id="pf-modal-close" aria-label="Close">×</button>
    </header>
    <div class="pf-tabs"><button type="button" class="is-active" data-tab="css">CSS variables</button><button type="button" data-tab="tw">Tailwind config</button></div>
    <textarea id="pf-export-text" readonly spellcheck="false"></textarea>
    <button type="button" class="pf-btn" id="pf-export-copy" data-i18n="copy_code">Copy code</button>
  </div>
</div>
