<?php $home = trailingslashit( home_url() ); ?>
<footer class="pf-footer">
  <div class="pf-wrap">
    <div class="pf-footer-grid">
      <div>
        <a class="pf-logo" href="<?php echo esc_url( $home ); ?>"><span>Palettify<em>.ai</em></span></a>
        <p class="pf-muted" data-i18n="footer_tag">AI-crafted color systems and type pairings for your next website.</p>
      </div>
      <div>
        <h4 data-i18n="footer_product">Product</h4>
        <a href="<?php echo esc_url( $home . '#generator' ); ?>" data-i18n="nav_tool">Generator</a>
        <a href="<?php echo esc_url( $home . '#features' ); ?>" data-i18n="nav_features">Features</a>
        <a href="<?php echo esc_url( $home . '#how' ); ?>" data-i18n="nav_how">How it works</a>
      </div>
      <div>
        <h4 data-i18n="footer_company">Company</h4>
        <a href="<?php echo esc_url( get_privacy_policy_url() ?: $home ); ?>" data-i18n="footer_privacy">Privacy</a>
        <a href="mailto:hello@palettify.ai">hello@palettify.ai</a>
      </div>
    </div>
    <div class="pf-footer-bottom">
      <span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> Palettify.ai — <span data-i18n="footer_rights">All rights reserved.</span></span>
    </div>
  </div>
</footer>

<!-- Floating AI Agent -->
<div class="pf-chat" id="pf-chat">
  <button class="pf-chat-fab" id="pf-chat-fab" type="button" aria-label="Open Palettify Assistant" aria-expanded="false">
    <span class="pf-fab-ring"></span>
    <svg class="pf-ic-open" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.9 4.6L18.5 9l-4.6 1.4L12 15l-1.9-4.6L5.5 9l4.6-1.4z"/><path d="M19 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/></svg>
    <svg class="pf-ic-close" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>
  </button>
  <section class="pf-chat-panel" id="pf-chat-panel" aria-label="Palettify Assistant" hidden>
    <header class="pf-chat-head">
      <span class="pf-chat-avatar"></span>
      <div><strong data-i18n="chat_title">Palettify Assistant</strong><small data-i18n="chat_sub">Design &amp; product guide</small></div>
    </header>
    <div class="pf-chat-log" id="pf-chat-log" aria-live="polite"></div>
    <div class="pf-chat-chips" id="pf-chat-chips"></div>
    <form class="pf-chat-form" id="pf-chat-form" autocomplete="off">
      <input type="text" id="pf-chat-input" maxlength="500" data-i18n-ph="chat_ph" placeholder="Ask about colors, fonts, Palettify…">
      <button type="submit" aria-label="Send"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/></svg></button>
    </form>
  </section>
</div>

<?php wp_footer(); ?>
</body>
</html>
