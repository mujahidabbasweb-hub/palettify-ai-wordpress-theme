<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'admin_menu', function () {
	add_theme_page( 'Palettify Settings', 'Palettify Settings', 'manage_options', 'palettify-settings', 'palettify_settings_page' );
} );

add_action( 'admin_init', function () {
	register_setting( 'palettify_settings', 'palettify_groq_api_key', array(
		'type'              => 'string',
		'sanitize_callback' => 'palettify_sanitize_api_key',
		'default'           => '',
	) );
} );

function palettify_sanitize_api_key( $value ) {
	$existing = get_option( 'palettify_groq_api_key', '' );
	if ( ! empty( $_POST['palettify_clear_key'] ) ) {
		return '';
	}
	$value = trim( sanitize_text_field( (string) $value ) );
	return $value === '' ? $existing : $value;
}

function palettify_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) return;
	$key    = get_option( 'palettify_groq_api_key', '' );
	$masked = $key ? str_repeat( '•', 12 ) . substr( $key, -4 ) : '';
	?>
	<div class="wrap">
		<h1>Palettify Settings</h1>
		<p>Connect Palettify.ai to Groq. Get a free key at <a href="https://console.groq.com/keys" target="_blank" rel="noopener">console.groq.com/keys</a>.</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'palettify_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="palettify_groq_api_key">Groq API Key</label></th>
					<td>
						<input type="password" id="palettify_groq_api_key" name="palettify_groq_api_key" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo $key ? esc_attr( $masked ) : 'gsk_...'; ?>">
						<p class="description">
							<?php echo $key ? '<strong style="color:#00a32a">✔ A key is saved.</strong> Leave blank to keep it, or paste a new one to replace it.' : '<strong style="color:#d63638">No key saved yet.</strong> The generator and chatbot will not work until you add one.'; ?>
						</p>
						<?php if ( $key ) : ?>
							<label><input type="checkbox" name="palettify_clear_key" value="1"> Remove saved key</label>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row">Model</th>
					<td><code>llama-3.3-70b-versatile</code> via <code>api.groq.com/openai/v1/chat/completions</code></td>
				</tr>
			</table>
			<?php submit_button( 'Save settings' ); ?>
		</form>
		<hr>
		<h2>Quick start</h2>
		<ol>
			<li>Paste your Groq key above and save.</li>
			<li>Your homepage already includes the generator. A dedicated page called <strong>Palettify</strong> (template: “Palettify Generator”) is created on activation.</li>
			<li>Settings → Reading → set “Your homepage displays” to <em>Your latest posts</em> (or leave it) — the theme’s <code>front-page.php</code> takes over automatically.</li>
		</ol>
	</div>
	<?php
}
