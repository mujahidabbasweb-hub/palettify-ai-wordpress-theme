<?php get_header(); ?>
<main>
  <section class="pf-hero">
    <div class="pf-wrap pf-hero-in">
      <div class="pf-hero-copy">
        <span class="pf-badge"><i></i><span data-i18n="hero_badge">Powered by Llama 3.3 on Groq</span></span>
        <h1 class="pf-h1"><span data-i18n="hero_title1">Your brand’s colors and fonts,</span> <span class="pf-grad-text" data-i18n="hero_title2">designed in seconds.</span></h1>
        <p class="pf-lead" data-i18n="hero_sub">Describe your website. Palettify.ai returns three complete design systems — palettes, type pairings, a live preview and ready-to-paste CSS.</p>
        <div class="pf-hero-cta">
          <a href="#generator" class="pf-btn" data-i18n="hero_cta1">Generate my design system</a>
          <a href="#how" class="pf-btn pf-btn-ghost" data-i18n="hero_cta2">See how it works</a>
        </div>
      </div>
      <div class="pf-hero-visual" aria-hidden="true">
        <div class="pf-float pf-float-a pf-gcard">
          <div class="pf-dots"><i style="background:#6366F1"></i><i style="background:#A855F7"></i><i style="background:#22D3EE"></i><i style="background:#F472B6"></i></div>
          <b>Aurora Night</b><small>Sora + Manrope</small>
        </div>
        <div class="pf-float pf-float-b pf-gcard">
          <div class="pf-mini-btn">Get started</div>
          <div class="pf-lines"><i></i><i></i><i></i></div>
        </div>
        <div class="pf-float pf-float-c pf-gcard"><code>--color-primary:<br>#6366F1;</code></div>
        <div class="pf-orb"></div>
      </div>
    </div>
  </section>

  <section class="pf-section" id="generator">
    <div class="pf-wrap"><?php get_template_part( 'template-parts/generator' ); ?></div>
  </section>

  <section class="pf-section" id="features">
    <div class="pf-wrap">
      <h2 class="pf-h2" data-i18n="feat_title">Everything a launch needs, nothing it doesn’t</h2>
      <div class="pf-grid-3">
        <article class="pf-gcard pf-feat"><div class="pf-feat-ic">🎨</div><h3 data-i18n="f1_t">Three tailored schemes</h3><p data-i18n="f1_d">Each tuned to your niche, audience and the culture of your target region.</p></article>
        <article class="pf-gcard pf-feat"><div class="pf-feat-ic">🔍</div><h3 data-i18n="f2_t">Live preview</h3><p data-i18n="f2_d">See a real UI card with your exact colors and fonts before you commit.</p></article>
        <article class="pf-gcard pf-feat"><div class="pf-feat-ic">⚡</div><h3 data-i18n="f3_t">One-click export</h3><p data-i18n="f3_d">Copy CSS variables or a Tailwind config and paste straight into your project.</p></article>
      </div>
    </div>
  </section>

  <section class="pf-section" id="how">
    <div class="pf-wrap">
      <h2 class="pf-h2" data-i18n="how_title">How it works</h2>
      <ol class="pf-steps">
        <li class="pf-gcard"><h3 data-i18n="s1_t">Describe your site</h3><p data-i18n="s1_d">Name, industry, audience, tech stack and region.</p></li>
        <li class="pf-gcard"><h3 data-i18n="s2_t">Compare three directions</h3><p data-i18n="s2_d">Review rationale, swatches, fonts and the live preview.</p></li>
        <li class="pf-gcard"><h3 data-i18n="s3_t">Export and build</h3><p data-i18n="s3_d">Copy HEX values, CSS variables or Tailwind config.</p></li>
      </ol>
    </div>
  </section>
</main>
<?php get_footer(); ?>
