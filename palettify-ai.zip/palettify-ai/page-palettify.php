<?php
/**
 * Template Name: Palettify Generator
 */
get_header(); ?>
<main class="pf-wrap pf-tool-page">
  <?php get_template_part( 'template-parts/generator' ); ?>
</main>
<?php get_footer(); ?>
