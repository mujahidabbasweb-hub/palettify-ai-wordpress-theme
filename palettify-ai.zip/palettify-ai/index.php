<?php get_header(); ?>
<main class="pf-wrap pf-page">
  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <article <?php post_class( 'pf-post pf-gcard' ); ?>>
      <h1 class="pf-post-title"><?php the_title(); ?></h1>
      <div class="pf-post-body"><?php the_content(); ?></div>
    </article>
  <?php endwhile; else : ?>
    <article class="pf-post pf-gcard"><h1 class="pf-post-title">404</h1><p>Nothing found here.</p></article>
  <?php endif; ?>
</main>
<?php get_footer(); ?>
