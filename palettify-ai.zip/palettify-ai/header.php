<?php
$langs = palettify_languages();
$cur   = palettify_current_lang();
$home  = trailingslashit( home_url() );
$tool  = get_page_by_path( 'palettify' ) ? get_permalink( get_page_by_path( 'palettify' ) ) : $home . '#generator';
?><!doctype html>
<html lang="<?php echo esc_attr( $cur ); ?>" dir="<?php echo esc_attr( palettify_current_dir() ); ?>">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0F172A">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'pf-body' ); ?>>
<?php wp_body_open(); ?>
<div class="pf-aurora" aria-hidden="true"><i></i><i></i><i></i><b></b></div>

<header class="pf-header" id="pf-header">
  <div class="pf-wrap pf-header-in">
    <a class="pf-logo" href="<?php echo esc_url( $home ); ?>" aria-label="Palettify.ai">
      <svg width="34" height="34" viewBox="0 0 40 40" aria-hidden="true">
        <defs><linearGradient id="pfg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6366F1"/><stop offset=".55" stop-color="#A855F7"/><stop offset="1" stop-color="#22D3EE"/></linearGradient></defs>
        <rect x="2" y="2" width="36" height="36" rx="11" fill="url(#pfg)"/>
        <circle cx="14" cy="15" r="4" fill="#fff" opacity=".95"/><circle cx="26" cy="14" r="3" fill="#fff" opacity=".7"/><circle cx="22" cy="26" r="5" fill="#fff" opacity=".9"/>
      </svg>
      <span>Palettify<em>.ai</em></span>
    </a>

    <nav class="pf-nav" id="pf-nav" aria-label="Main">
      <a href="<?php echo esc_url( $home ); ?>" data-i18n="nav_home">Home</a>
      <a href="<?php echo esc_url( $tool ); ?>" data-i18n="nav_tool">Generator</a>
      <a href="<?php echo esc_url( $home . '#features' ); ?>" data-i18n="nav_features">Features</a>
      <a href="<?php echo esc_url( $home . '#how' ); ?>" data-i18n="nav_how">How it works</a>
    </nav>

    <div class="pf-header-actions">
      <div class="pf-lang" id="pf-lang">
        <button class="pf-lang-btn" type="button" aria-haspopup="listbox" aria-expanded="false" aria-label="Language">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18"/></svg>
          <span id="pf-lang-label"><?php echo esc_html( $langs[ $cur ]['native'] ); ?></span>
          <svg class="pf-chev" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="m6 9 6 6 6-6"/></svg>
        </button>
        <ul class="pf-lang-menu" role="listbox">
          <?php foreach ( $langs as $code => $l ) : ?>
            <li><button type="button" role="option" data-lang="<?php echo esc_attr( $code ); ?>" class="<?php echo $code === $cur ? 'is-active' : ''; ?>"><span><?php echo esc_html( $l['flag'] ); ?></span> <?php echo esc_html( $l['native'] ); ?></button></li>
          <?php endforeach; ?>
        </ul>
      </div>
      <a class="pf-btn pf-btn-sm" href="<?php echo esc_url( $tool ); ?>" data-i18n="nav_cta">Try it free</a>
      <button class="pf-burger" id="pf-burger" type="button" aria-label="Menu" aria-expanded="false"><i></i><i></i><i></i></button>
    </div>
  </div>
</header>
