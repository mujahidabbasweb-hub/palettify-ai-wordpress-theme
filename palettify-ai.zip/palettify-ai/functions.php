<?php
/**
 * Palettify-AI theme core.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'PALETTIFY_VERSION', '1.0.0' );
define( 'PALETTIFY_GROQ_URL', 'https://api.groq.com/openai/v1/chat/completions' );

// Is line ko change karein:

require_once get_template_directory() . '/admin-settings.php';

/* ---------- Setup ---------- */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'gallery', 'caption', 'style', 'script' ) );
	register_nav_menus( array( 'primary' => 'Primary Menu' ) );
} );

/* Create the generator page on activation */
add_action( 'after_switch_theme', function () {
	if ( ! get_page_by_path( 'palettify' ) ) {
		$id = wp_insert_post( array(
			'post_title'  => 'Palettify',
			'post_name'   => 'palettify',
			'post_status' => 'publish',
			'post_type'   => 'page',
		) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_wp_page_template', 'page-palettify.php' );
		}
	}
	flush_rewrite_rules();
} );

/* ---------- Languages ---------- */
function palettify_languages() {
	return array(
		'en' => array( 'name' => 'English',  'native' => 'English',  'dir' => 'ltr', 'flag' => '🇬🇧' ),
		'fr' => array( 'name' => 'French',   'native' => 'Français', 'dir' => 'ltr', 'flag' => '🇫🇷' ),
		'ar' => array( 'name' => 'Arabic',   'native' => 'العربية',  'dir' => 'rtl', 'flag' => '🇸🇦' ),
		'es' => array( 'name' => 'Spanish',  'native' => 'Español',  'dir' => 'ltr', 'flag' => '🇪🇸' ),
	);
}
function palettify_current_lang() {
	$l = isset( $_COOKIE['palettify_lang'] ) ? sanitize_key( wp_unslash( $_COOKIE['palettify_lang'] ) ) : 'en';
	return array_key_exists( $l, palettify_languages() ) ? $l : 'en';
}
function palettify_current_dir() {
	$langs = palettify_languages();
	return $langs[ palettify_current_lang() ]['dir'];
}

/* ---------- Assets ---------- */
add_action( 'wp_enqueue_scripts', function () {
	$uri = get_template_directory_uri();
	wp_enqueue_style( 'palettify-fonts', 'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=Sora:wght@500;600;700;800&family=Cairo:wght@400;600;700&display=swap', array(), null );
	wp_enqueue_style( 'palettify-style', get_stylesheet_uri(), array(), PALETTIFY_VERSION );
	wp_enqueue_style( 'palettify-main', $uri . '/assets/css/main.css', array( 'palettify-style' ), PALETTIFY_VERSION );
	wp_enqueue_style( 'palettify-rtl', $uri . '/assets/css/rtl.css', array( 'palettify-main' ), PALETTIFY_VERSION );
	wp_enqueue_script( 'palettify-app', $uri . '/assets/js/app.js', array(), PALETTIFY_VERSION, true );
	wp_localize_script( 'palettify-app', 'PALETTIFY', array(
		'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'palettify_nonce' ),
		'lang'    => palettify_current_lang(),
	) );
} );

/* ---------- Helpers ---------- */
function palettify_rate_limit( $bucket, $max, $window = 600 ) {
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'x';
	$key = 'pf_rl_' . md5( $bucket . $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= $max ) return false;
	set_transient( $key, $n + 1, $window );
	return true;
}

function palettify_groq_request( $messages, $opts = array() ) {
	$api_key = trim( (string) get_option( 'palettify_groq_api_key', '' ) );
	if ( $api_key === '' ) {
		return new WP_Error( 'no_key', 'The Groq API key is not configured. Add it in Appearance → Palettify Settings.' );
	}
	
	$body = array(
		'model'       => PALETTIFY_GROQ_MODEL,
		'messages'    => $messages,
		'temperature' => isset( $opts['temperature'] ) ? $opts['temperature'] : 0.7,
		'max_tokens'  => isset( $opts['max_tokens'] ) ? $opts['max_tokens'] : 1500,
	);

	if ( ! empty( $opts['json'] ) ) {
		$body['response_format'] = array( 'type' => 'json_object' );
	}

	$res = wp_remote_post( PALETTIFY_GROQ_URL, array(
		'timeout' => 60,
		'headers' => array(
			'Authorization' => 'Bearer ' . $api_key,
			'Content-Type'  => 'application/json',
		),
		'body'    => wp_json_encode( $body ),
	) );

	if ( is_wp_error( $res ) ) return $res;

	$code = wp_remote_retrieve_response_code( $res );
	$data = json_decode( wp_remote_retrieve_body( $res ), true );

	if ( $code !== 200 || empty( $data['choices'][0]['message']['content'] ) ) {
		$msg = isset( $data['error']['message'] ) ? $data['error']['message'] : 'Unexpected response from Groq (HTTP ' . $code . ').';
		return new WP_Error( 'groq_error', $msg );
	}

	return $data['choices'][0]['message']['content'];
}

function palettify_posted_lang() {
	$l = isset( $_POST['lang'] ) ? sanitize_key( wp_unslash( $_POST['lang'] ) ) : 'en';
	$langs = palettify_languages();
	return isset( $langs[ $l ] ) ? $l : 'en';
}

function palettify_hex( $v, $fallback ) {
	$v = is_string( $v ) ? trim( $v ) : '';
	if ( preg_match( '/^#([0-9a-fA-F]{6})$/', $v ) ) return strtoupper( $v );
	if ( preg_match( '/^#([0-9a-fA-F]{3})$/', $v, $m ) ) {
		$c = $m[1];
		return strtoupper( '#' . $c[0] . $c[0] . $c[1] . $c[1] . $c[2] . $c[2] );
	}
	return $fallback;
}

function palettify_font( $v, $fallback ) {
	$v = is_string( $v ) ? trim( preg_replace( '/[^A-Za-z0-9 ]/', '', $v ) ) : '';
	return $v !== '' ? substr( $v, 0, 40 ) : $fallback;
}

/* ---------- AJAX: Generator ---------- */
add_action( 'wp_ajax_palettify_generate_design', 'palettify_ajax_generate' );
add_action( 'wp_ajax_nopriv_palettify_generate_design', 'palettify_ajax_generate' );

function palettify_ajax_generate() {
	check_ajax_referer( 'palettify_nonce', 'nonce' );

	if ( ! palettify_rate_limit( 'gen', 20 ) ) {
		wp_send_json_error( array( 'message' => 'Too many requests. Please try again in a few minutes.' ), 429 );
	}

	$f = array();
	foreach ( array( 'name', 'industry', 'mood', 'stack', 'country' ) as $k ) {
		$f[ $k ] = isset( $_POST[ $k ] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST[ $k ] ) ), 0, 120 ) : '';
	}

	if ( $f['name'] === '' || $f['industry'] === '' || $f['mood'] === '' ) {
		wp_send_json_error( array( 'message' => 'Please fill in website name, industry and audience/mood.' ), 400 );
	}

	$langs     = palettify_languages();
	$lang_name = $langs[ palettify_posted_lang() ]['name'];

	$system = 'You are a senior brand and UI designer who creates web design systems. Respond with ONLY valid JSON, no markdown. '
		. 'Schema: {"schemes":[{"title":string,"rationale":string,"colors":{"background":"#RRGGBB","primary":"#RRGGBB","heading":"#RRGGBB","body":"#RRGGBB","button_bg":"#RRGGBB","button_text":"#RRGGBB"},"fonts":{"heading":string,"body":string}}]}. '
		. 'Return exactly 3 clearly different schemes. Ensure strong text contrast (WCAG AA) between heading/body and background, and between button_text and button_bg. '
		. 'Fonts MUST exist on Google Fonts and be written with their exact Google Fonts family names. '
		. 'Write "title" and "rationale" (2-3 sentences covering color psychology, audience and cultural fit for the target region) in ' . $lang_name . '. Keep JSON keys, hex codes and font names in Latin script.';

	$user = sprintf(
		"Website name: %s\nIndustry / niche: %s\nTarget audience / mood: %s\nTech stack / CMS: %s\nTarget country / region: %s",
		$f['name'], $f['industry'], $f['mood'], $f['stack'] ?: 'not specified', $f['country'] ?: 'global'
	);

	$out = palettify_groq_request(
		array( array( 'role' => 'system', 'content' => $system ), array( 'role' => 'user', 'content' => $user ) ),
		array( 'json' => true, 'temperature' => 0.8, 'max_tokens' => 2200 )
	);

	if ( is_wp_error( $out ) ) {
		wp_send_json_error( array( 'message' => $out->get_error_message() ), 502 );
	}

	$data = json_decode( $out, true );
	if ( ! is_array( $data ) ) {
		$s = strpos( $out, '{' ); $e = strrpos( $out, '}' );
		if ( $s !== false && $e !== false ) $data = json_decode( substr( $out, $s, $e - $s + 1 ), true );
	}

	if ( empty( $data['schemes'] ) || ! is_array( $data['schemes'] ) ) {
		wp_send_json_error( array( 'message' => 'The AI returned an unreadable result. Please try again.' ), 502 );
	}

	$schemes = array();
	foreach ( array_slice( $data['schemes'], 0, 3 ) as $s ) {
		$c = isset( $s['colors'] ) && is_array( $s['colors'] ) ? $s['colors'] : array();
		$ft = isset( $s['fonts'] ) && is_array( $s['fonts'] ) ? $s['fonts'] : array();
		$schemes[] = array(
			'title'     => isset( $s['title'] ) ? sanitize_text_field( $s['title'] ) : 'Scheme',
			'rationale' => isset( $s['rationale'] ) ? sanitize_textarea_field( $s['rationale'] ) : '',
			'colors'    => array(
				'background'  => palettify_hex( isset( $c['background'] ) ? $c['background'] : '', '#0F172A' ),
				'primary'     => palettify_hex( isset( $c['primary'] ) ? $c['primary'] : '', '#6366F1' ),
				'heading'     => palettify_hex( isset( $c['heading'] ) ? $c['heading'] : '', '#FFFFFF' ),
				'body'        => palettify_hex( isset( $c['body'] ) ? $c['body'] : '', '#CBD5E1' ),
				'button_bg'   => palettify_hex( isset( $c['button_bg'] ) ? $c['button_bg'] : '', '#6366F1' ),
				'button_text' => palettify_hex( isset( $c['button_text'] ) ? $c['button_text'] : '', '#FFFFFF' ),
			),
			'fonts'     => array(
				'heading' => palettify_font( isset( $ft['heading'] ) ? $ft['heading'] : '', 'Sora' ),
				'body'    => palettify_font( isset( $ft['body'] ) ? $ft['body'] : '', 'Inter' ),
			),
		);
	}

	wp_send_json_success( array( 'schemes' => $schemes ) );
}

/* ---------- AJAX: Chatbot ---------- */
add_action( 'wp_ajax_palettify_ai_chat', 'palettify_ajax_chat' );
add_action( 'wp_ajax_nopriv_palettify_ai_chat', 'palettify_ajax_chat' );

function palettify_ajax_chat() {
	check_ajax_referer( 'palettify_nonce', 'nonce' );

	if ( ! palettify_rate_limit( 'chat', 50 ) ) {
		wp_send_json_error( array( 'message' => 'You are sending messages too fast. Please wait a few minutes.' ), 429 );
	}

	$langs     = palettify_languages();
	$lang_name = $langs[ palettify_posted_lang() ]['name'];

	$history = array();
	if ( isset( $_POST['history'] ) ) {
		$raw = json_decode( wp_unslash( $_POST['history'] ), true );
		if ( is_array( $raw ) ) {
			foreach ( array_slice( $raw, -10 ) as $m ) {
				if ( empty( $m['role'] ) || ! isset( $m['content'] ) ) continue;
				if ( ! in_array( $m['role'], array( 'user', 'assistant' ), true ) ) continue;
				$history[] = array(
					'role'    => $m['role'],
					'content' => mb_substr( sanitize_textarea_field( (string) $m['content'] ), 0, 1500 ),
				);
			}
		}
	}

	$msg = isset( $_POST['message'] ) ? mb_substr( sanitize_textarea_field( wp_unslash( $_POST['message'] ) ), 0, 1500 ) : '';
	if ( $msg === '' ) {
		wp_send_json_error( array( 'message' => 'Empty message.' ), 400 );
	}

	$system = 'You are Palettify Assistant, an expert AI agent embedded inside Palettify.ai. Your job is to explain to users how Palettify.ai works, guide them on how to enter their website details, explain color psychology, typography choices, and assist them with web design questions. '
		. 'Palettify.ai generates 3 tailored design schemes (colors, typography, live preview, CSS variables and Tailwind export) from the website name, industry, audience/mood, tech stack and target region. '
		. 'Always reply in ' . $lang_name . '. Be concise, friendly and practical; use short paragraphs or bullets.';

	$messages = array_merge( array( array( 'role' => 'system', 'content' => $system ) ), $history, array( array( 'role' => 'user', 'content' => $msg ) ) );

	$out = palettify_groq_request( $messages, array( 'temperature' => 0.6, 'max_tokens' => 700 ) );

	if ( is_wp_error( $out ) ) {
		wp_send_json_error( array( 'message' => $out->get_error_message() ), 502 );
	}

	wp_send_json_success( array( 'reply' => $out ) );
}