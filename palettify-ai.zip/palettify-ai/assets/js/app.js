(function () {
  'use strict';
  var C = window.PALETTIFY || {};
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* ================= i18n ================= */
  var T = {
    en: {
      nav_home:'Home',nav_tool:'Generator',nav_features:'Features',nav_how:'How it works',nav_cta:'Try it free',
      hero_badge:'Powered by Llama 3.3 on Groq',hero_title1:'Your brand’s colors and fonts,',hero_title2:'designed in seconds.',
      hero_sub:'Describe your website. Palettify.ai returns three complete design systems — palettes, type pairings, a live preview and ready-to-paste CSS.',
      hero_cta1:'Generate my design system',hero_cta2:'See how it works',
      feat_title:'Everything a launch needs, nothing it doesn’t',
      f1_t:'Three tailored schemes',f1_d:'Each tuned to your niche, audience and the culture of your target region.',
      f2_t:'Live preview',f2_d:'See a real UI card with your exact colors and fonts before you commit.',
      f3_t:'One-click export',f3_d:'Copy CSS variables or a Tailwind config and paste straight into your project.',
      how_title:'How it works',s1_t:'Describe your site',s1_d:'Name, industry, audience, tech stack and region.',
      s2_t:'Compare three directions',s2_d:'Review rationale, swatches, fonts and the live preview.',s3_t:'Export and build',s3_d:'Copy HEX values, CSS variables or Tailwind config.',
      tool_title:'Design system generator',tool_sub:'Tell us about your website. We’ll craft three tailored directions.',
      lbl_name:'Website name',lbl_industry:'Industry / niche',lbl_mood:'Target audience / mood',lbl_stack:'Tech stack / CMS',lbl_country:'Target country / region',
      ph_name:'e.g. Luma Skincare',ph_industry:'e.g. Organic beauty',ph_mood:'e.g. Women 25–40, calm, trustworthy, natural',ph_country:'e.g. United Arab Emirates',
      btn_generate:'Generate 3 schemes',btn_working:'Generating…',loading:'Mixing colors and pairing fonts…',
      err_fields:'Fill in website name, industry and audience/mood.',err_generic:'Something went wrong. Please try again.',
      c_bg:'Background',c_primary:'Primary',c_heading:'Heading',c_body:'Body',c_btnbg:'Button BG',c_btntext:'Button text',copy_hex:'Copy HEX',copied:'Copied!',
      live_preview:'Live preview',typography:'Typography',heading_font:'Heading',body_font:'Body',export:'Export CSS & Tailwind',export_title:'Export design system',copy_code:'Copy code',
      pv_tag:'New',pv_h:'Launch faster with confidence',pv_p:'A clear, balanced interface built from your own palette and type.',pv_btn:'Get started',pv_link:'Learn more',
      chat_title:'Palettify Assistant',chat_sub:'Design & product guide',chat_ph:'Ask about colors, fonts, Palettify…',
      chat_welcome:'Hi! I’m Palettify Assistant. I can show you how to use Palettify.ai, explain color psychology or help pick fonts. What are you building?',
      chip1:'How does it work?',chip2:'Color psychology',chip3:'Pick fonts',chip_q1:'How does Palettify.ai work?',chip_q2:'Explain color psychology for a website.',chip_q3:'How do I choose font pairings?',
      chat_err:'I couldn’t reach the AI right now. Please try again.',
      footer_tag:'AI-crafted color systems and type pairings for your next website.',footer_product:'Product',footer_company:'Company',footer_privacy:'Privacy',footer_rights:'All rights reserved.'
    },
    fr: {
      nav_home:'Accueil',nav_tool:'Générateur',nav_features:'Fonctionnalités',nav_how:'Comment ça marche',nav_cta:'Essayer gratuitement',
      hero_badge:'Propulsé par Llama 3.3 sur Groq',hero_title1:'Les couleurs et polices de votre marque,',hero_title2:'conçues en quelques secondes.',
      hero_sub:'Décrivez votre site. Palettify.ai génère trois design systems complets : palettes, associations typographiques, aperçu en direct et CSS prêt à copier.',
      hero_cta1:'Générer mon design system',hero_cta2:'Voir comment ça marche',
      feat_title:'Tout ce qu’il faut pour se lancer, rien de superflu',
      f1_t:'Trois schémas sur mesure',f1_d:'Adaptés à votre secteur, votre audience et la culture de votre région cible.',
      f2_t:'Aperçu en direct',f2_d:'Visualisez une vraie carte d’interface avec vos couleurs et polices exactes.',
      f3_t:'Export en un clic',f3_d:'Copiez les variables CSS ou la config Tailwind directement dans votre projet.',
      how_title:'Comment ça marche',s1_t:'Décrivez votre site',s1_d:'Nom, secteur, audience, stack technique et région.',
      s2_t:'Comparez trois directions',s2_d:'Analysez la justification, les couleurs, les polices et l’aperçu.',s3_t:'Exportez et construisez',s3_d:'Copiez les codes HEX, variables CSS ou config Tailwind.',
      tool_title:'Générateur de design system',tool_sub:'Parlez-nous de votre site. Nous créons trois directions sur mesure.',
      lbl_name:'Nom du site',lbl_industry:'Secteur / niche',lbl_mood:'Audience cible / ambiance',lbl_stack:'Stack technique / CMS',lbl_country:'Pays / région cible',
      ph_name:'ex. Luma Skincare',ph_industry:'ex. Beauté bio',ph_mood:'ex. Femmes 25–40 ans, calme, fiable, naturel',ph_country:'ex. Émirats arabes unis',
      btn_generate:'Générer 3 schémas',btn_working:'Génération…',loading:'Mélange des couleurs et choix des polices…',
      err_fields:'Renseignez le nom, le secteur et l’audience/ambiance.',err_generic:'Une erreur est survenue. Veuillez réessayer.',
      c_bg:'Arrière-plan',c_primary:'Principale',c_heading:'Titres',c_body:'Texte',c_btnbg:'Fond bouton',c_btntext:'Texte bouton',copy_hex:'Copier HEX',copied:'Copié !',
      live_preview:'Aperçu en direct',typography:'Typographie',heading_font:'Titres',body_font:'Texte',export:'Exporter CSS & Tailwind',export_title:'Exporter le design system',copy_code:'Copier le code',
      pv_tag:'Nouveau',pv_h:'Lancez-vous plus vite, en confiance',pv_p:'Une interface claire et équilibrée, bâtie sur votre palette et vos polices.',pv_btn:'Commencer',pv_link:'En savoir plus',
      chat_title:'Assistant Palettify',chat_sub:'Guide design & produit',chat_ph:'Posez une question sur les couleurs, polices…',
      chat_welcome:'Bonjour ! Je suis l’assistant Palettify. Je peux vous expliquer Palettify.ai, la psychologie des couleurs ou le choix des polices. Que construisez-vous ?',
      chip1:'Comment ça marche ?',chip2:'Psychologie des couleurs',chip3:'Choisir des polices',chip_q1:'Comment fonctionne Palettify.ai ?',chip_q2:'Explique la psychologie des couleurs pour un site web.',chip_q3:'Comment choisir des associations de polices ?',
      chat_err:'Impossible de joindre l’IA pour le moment. Réessayez.',
      footer_tag:'Systèmes de couleurs et typographies créés par IA pour votre prochain site.',footer_product:'Produit',footer_company:'Société',footer_privacy:'Confidentialité',footer_rights:'Tous droits réservés.'
    },
    ar: {
      nav_home:'الرئيسية',nav_tool:'المولّد',nav_features:'المزايا',nav_how:'كيف يعمل',nav_cta:'جرّب مجاناً',
      hero_badge:'مدعوم بـ Llama 3.3 على Groq',hero_title1:'ألوان وخطوط علامتك التجارية،',hero_title2:'مصمَّمة في ثوانٍ.',
      hero_sub:'صف موقعك وسيقدّم لك Palettify.ai ثلاثة أنظمة تصميم متكاملة: لوحات ألوان، وتزاوج خطوط، ومعاينة مباشرة، وكود CSS جاهز للنسخ.',
      hero_cta1:'أنشئ نظام التصميم',hero_cta2:'شاهد كيف يعمل',
      feat_title:'كل ما يحتاجه الإطلاق، دون زيادة',
      f1_t:'ثلاثة مخططات مخصّصة',f1_d:'مضبوطة وفق مجالك وجمهورك وثقافة منطقتك المستهدفة.',
      f2_t:'معاينة مباشرة',f2_d:'شاهد بطاقة واجهة حقيقية بألوانك وخطوطك قبل الاعتماد.',
      f3_t:'تصدير بنقرة واحدة',f3_d:'انسخ متغيرات CSS أو إعدادات Tailwind والصقها في مشروعك.',
      how_title:'كيف يعمل',s1_t:'صف موقعك',s1_d:'الاسم والمجال والجمهور والتقنيات والمنطقة.',
      s2_t:'قارن بين ثلاثة اتجاهات',s2_d:'راجع المبررات والألوان والخطوط والمعاينة المباشرة.',s3_t:'صدّر وابدأ البناء',s3_d:'انسخ أكواد HEX أو متغيرات CSS أو إعدادات Tailwind.',
      tool_title:'مولّد نظام التصميم',tool_sub:'أخبرنا عن موقعك وسنصمم لك ثلاثة اتجاهات مخصّصة.',
      lbl_name:'اسم الموقع',lbl_industry:'المجال / التخصص',lbl_mood:'الجمهور المستهدف / الأجواء',lbl_stack:'التقنيات / نظام إدارة المحتوى',lbl_country:'الدولة / المنطقة المستهدفة',
      ph_name:'مثال: لوما للعناية بالبشرة',ph_industry:'مثال: مستحضرات تجميل عضوية',ph_mood:'مثال: نساء ٢٥–٤٠، هادئ، موثوق، طبيعي',ph_country:'مثال: الإمارات العربية المتحدة',
      btn_generate:'أنشئ 3 مخططات',btn_working:'جارٍ الإنشاء…',loading:'نمزج الألوان ونختار الخطوط…',
      err_fields:'أدخل اسم الموقع والمجال والجمهور/الأجواء.',err_generic:'حدث خطأ ما. حاول مرة أخرى.',
      c_bg:'الخلفية',c_primary:'الأساسي',c_heading:'العناوين',c_body:'النص',c_btnbg:'خلفية الزر',c_btntext:'نص الزر',copy_hex:'نسخ HEX',copied:'تم النسخ!',
      live_preview:'معاينة مباشرة',typography:'الخطوط',heading_font:'العناوين',body_font:'النص',export:'تصدير CSS و Tailwind',export_title:'تصدير نظام التصميم',copy_code:'نسخ الكود',
      pv_tag:'جديد',pv_h:'أطلق مشروعك بسرعة وثقة',pv_p:'واجهة واضحة ومتوازنة مبنية على لوحة ألوانك وخطوطك.',pv_btn:'ابدأ الآن',pv_link:'اعرف المزيد',
      chat_title:'مساعد Palettify',chat_sub:'دليل التصميم والمنتج',chat_ph:'اسأل عن الألوان والخطوط…',
      chat_welcome:'مرحباً! أنا مساعد Palettify. أشرح لك طريقة استخدام Palettify.ai وسيكولوجية الألوان واختيار الخطوط. ماذا تبني؟',
      chip1:'كيف يعمل؟',chip2:'سيكولوجية الألوان',chip3:'اختيار الخطوط',chip_q1:'كيف يعمل Palettify.ai؟',chip_q2:'اشرح سيكولوجية الألوان لموقع إلكتروني.',chip_q3:'كيف أختار تزاوج الخطوط؟',
      chat_err:'تعذّر الاتصال بالذكاء الاصطناعي الآن. حاول مجدداً.',
      footer_tag:'أنظمة ألوان وخطوط مصمَّمة بالذكاء الاصطناعي لموقعك القادم.',footer_product:'المنتج',footer_company:'الشركة',footer_privacy:'الخصوصية',footer_rights:'جميع الحقوق محفوظة.'
    },
    es: {
      nav_home:'Inicio',nav_tool:'Generador',nav_features:'Funciones',nav_how:'Cómo funciona',nav_cta:'Prueba gratis',
      hero_badge:'Impulsado por Llama 3.3 en Groq',hero_title1:'Los colores y tipografías de tu marca,',hero_title2:'diseñados en segundos.',
      hero_sub:'Describe tu sitio web. Palettify.ai devuelve tres sistemas de diseño completos: paletas, combinaciones tipográficas, vista previa en vivo y CSS listo para pegar.',
      hero_cta1:'Generar mi sistema de diseño',hero_cta2:'Ver cómo funciona',
      feat_title:'Todo lo que necesita un lanzamiento, nada más',
      f1_t:'Tres esquemas a medida',f1_d:'Ajustados a tu nicho, tu audiencia y la cultura de tu región objetivo.',
      f2_t:'Vista previa en vivo',f2_d:'Mira una tarjeta de interfaz real con tus colores y fuentes exactos.',
      f3_t:'Exportación en un clic',f3_d:'Copia variables CSS o la config de Tailwind y pégala en tu proyecto.',
      how_title:'Cómo funciona',s1_t:'Describe tu sitio',s1_d:'Nombre, sector, audiencia, tecnología y región.',
      s2_t:'Compara tres direcciones',s2_d:'Revisa la justificación, los colores, las fuentes y la vista previa.',s3_t:'Exporta y construye',s3_d:'Copia códigos HEX, variables CSS o config de Tailwind.',
      tool_title:'Generador de sistema de diseño',tool_sub:'Cuéntanos sobre tu sitio. Crearemos tres direcciones a medida.',
      lbl_name:'Nombre del sitio',lbl_industry:'Sector / nicho',lbl_mood:'Audiencia objetivo / ambiente',lbl_stack:'Tecnología / CMS',lbl_country:'País / región objetivo',
      ph_name:'p. ej. Luma Skincare',ph_industry:'p. ej. Belleza orgánica',ph_mood:'p. ej. Mujeres 25–40, calma, confianza, natural',ph_country:'p. ej. Emiratos Árabes Unidos',
      btn_generate:'Generar 3 esquemas',btn_working:'Generando…',loading:'Mezclando colores y combinando fuentes…',
      err_fields:'Completa nombre, sector y audiencia/ambiente.',err_generic:'Algo salió mal. Inténtalo de nuevo.',
      c_bg:'Fondo',c_primary:'Primario',c_heading:'Títulos',c_body:'Texto',c_btnbg:'Fondo botón',c_btntext:'Texto botón',copy_hex:'Copiar HEX',copied:'¡Copiado!',
      live_preview:'Vista previa en vivo',typography:'Tipografía',heading_font:'Títulos',body_font:'Texto',export:'Exportar CSS y Tailwind',export_title:'Exportar sistema de diseño',copy_code:'Copiar código',
      pv_tag:'Nuevo',pv_h:'Lanza más rápido y con confianza',pv_p:'Una interfaz clara y equilibrada creada con tu paleta y tipografía.',pv_btn:'Empezar',pv_link:'Saber más',
      chat_title:'Asistente Palettify',chat_sub:'Guía de diseño y producto',chat_ph:'Pregunta sobre colores, fuentes…',
      chat_welcome:'¡Hola! Soy el asistente de Palettify. Te explico cómo usar Palettify.ai, psicología del color o cómo elegir fuentes. ¿Qué estás creando?',
      chip1:'¿Cómo funciona?',chip2:'Psicología del color',chip3:'Elegir fuentes',chip_q1:'¿Cómo funciona Palettify.ai?',chip_q2:'Explica la psicología del color para un sitio web.',chip_q3:'¿Cómo elijo combinaciones de fuentes?',
      chat_err:'No pude conectar con la IA ahora. Inténtalo de nuevo.',
      footer_tag:'Sistemas de color y tipografía creados con IA para tu próximo sitio.',footer_product:'Producto',footer_company:'Compañía',footer_privacy:'Privacidad',footer_rights:'Todos los derechos reservados.'
    }
  };
  var NATIVE = { en: 'English', fr: 'Français', ar: 'العربية', es: 'Español' };
  var lang = T[C.lang] ? C.lang : 'en';
  var t = function (k) { return (T[lang] && T[lang][k]) || T.en[k] || k; };

  function applyLang() {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    $$('[data-i18n]').forEach(function (el) { el.textContent = t(el.getAttribute('data-i18n')); });
    $$('[data-i18n-ph]').forEach(function (el) { el.placeholder = t(el.getAttribute('data-i18n-ph')); });
    var lbl = $('#pf-lang-label'); if (lbl) lbl.textContent = NATIVE[lang];
    $$('.pf-lang-menu button').forEach(function (b) { b.classList.toggle('is-active', b.dataset.lang === lang); });
    buildChips();
    var first = $('.pf-msg-bot[data-welcome]'); if (first) first.innerHTML = '<p>' + esc(t('chat_welcome')) + '</p>';
  }
  function setLang(l) {
    if (!T[l]) return;
    lang = l; C.lang = l;
    document.cookie = 'palettify_lang=' + l + ';path=/;max-age=31536000;SameSite=Lax';
    applyLang();
  }

  /* ================= helpers ================= */
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var HEX = /^#[0-9A-F]{6}$/i;
  function hex(v, f) { return HEX.test(v) ? v.toUpperCase() : f; }
  function fam(v) { return String(v || '').replace(/[^A-Za-z0-9 ]/g, '').trim() || 'Inter'; }
  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
    return new Promise(function (res) {
      var ta = document.createElement('textarea'); ta.value = text; ta.style.cssText = 'position:fixed;opacity:0';
      document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch (e) {} ta.remove(); res();
    });
  }
  function loadFont(name) {
    var id = 'pf-font-' + name.replace(/ /g, '-');
    if (document.getElementById(id)) return;
    var l = document.createElement('link'); l.id = id; l.rel = 'stylesheet';
    l.href = 'https://fonts.googleapis.com/css2?family=' + encodeURIComponent(name).replace(/%20/g, '+') + ':wght@400;500;600;700&display=swap';
    document.head.appendChild(l);
  }
  function post(action, data) {
    var fd = new FormData();
    fd.append('action', action); fd.append('nonce', C.nonce); fd.append('lang', lang);
    Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
    return fetch(C.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); });
  }

  /* ================= header ================= */
  var header = $('#pf-header');
  function onScroll() { if (header) header.classList.toggle('is-scrolled', window.scrollY > 12); }
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();

  var langBox = $('#pf-lang');
  if (langBox) {
    var lb = $('.pf-lang-btn', langBox);
    lb.addEventListener('click', function (e) { e.stopPropagation(); var o = langBox.classList.toggle('is-open'); lb.setAttribute('aria-expanded', o); });
    $$('.pf-lang-menu button').forEach(function (b) {
      b.addEventListener('click', function () { setLang(b.dataset.lang); langBox.classList.remove('is-open'); lb.setAttribute('aria-expanded', 'false'); });
    });
    document.addEventListener('click', function (e) { if (!langBox.contains(e.target)) langBox.classList.remove('is-open'); });
  }
  var burger = $('#pf-burger'), nav = $('#pf-nav');
  if (burger) {
    burger.addEventListener('click', function () { var o = nav.classList.toggle('is-open'); burger.setAttribute('aria-expanded', o); });
    $$('a', nav).forEach(function (a) { a.addEventListener('click', function () { nav.classList.remove('is-open'); burger.setAttribute('aria-expanded', 'false'); }); });
  }

  // spotlight follows cursor
  document.addEventListener('pointermove', function (e) {
    var c = e.target.closest && e.target.closest('.pf-spot');
    if (!c) return; var r = c.getBoundingClientRect();
    c.style.setProperty('--mx', (e.clientX - r.left) + 'px'); c.style.setProperty('--my', (e.clientY - r.top) + 'px');
  }, { passive: true });

  /* ================= generator ================= */
  var form = $('#pf-form');
  var results = $('#pf-results'), loading = $('#pf-loading'), errBox = $('#pf-error');
  var schemes = [];

  function showErr(m) { if (!errBox) return; errBox.textContent = m; errBox.hidden = !m; }

  function swatch(label, color) {
    return '<button type="button" class="pf-sw" data-hex="' + color + '" style="--c:' + color + '">' +
      '<span class="pf-sw-chip"></span><span class="pf-sw-txt"><b>' + esc(label) + '</b><code>' + color + '</code><span data-copy>' + esc(t('copy_hex')) + '</span></span></button>';
  }

  function renderScheme(s, i) {
    var c = s.colors, f = s.fonts;
    var bg = hex(c.background, '#0F172A'), pr = hex(c.primary, '#6366F1'), hd = hex(c.heading, '#FFFFFF'),
        bd = hex(c.body, '#CBD5E1'), bb = hex(c.button_bg, '#6366F1'), bt = hex(c.button_text, '#FFFFFF');
    var fh = fam(f.heading), fb = fam(f.body);
    loadFont(fh); loadFont(fb);
    return '<article class="pf-scheme pf-gcard pf-spot" style="--bg:' + bg + ';--pr:' + pr + ';--hd:' + hd + ';--bd:' + bd + ';--bb:' + bb + ';--bt:' + bt + ";--fh:'" + fh + "';--fb:'" + fb + "'\" data-i=\"" + i + '">' +
      '<div class="pf-scheme-head"><span class="pf-rank">' + (i + 1) + '</span><h3>' + esc(s.title) + '</h3></div>' +
      '<p class="pf-rationale">' + esc(s.rationale) + '</p>' +
      '<div class="pf-swatches">' + swatch(t('c_bg'), bg) + swatch(t('c_primary'), pr) + swatch(t('c_heading'), hd) + swatch(t('c_body'), bd) + swatch(t('c_btnbg'), bb) + swatch(t('c_btntext'), bt) + '</div>' +
      '<div class="pf-sub">' + esc(t('live_preview')) + '</div>' +
      '<div class="pf-pv"><div class="pf-pv-bar"><i></i><i></i><i></i></div><div class="pf-pv-body">' +
        '<span class="pf-pv-tag">' + esc(t('pv_tag')) + '</span><h4>' + esc(t('pv_h')) + '</h4><p>' + esc(t('pv_p')) + '</p>' +
        '<div class="pf-pv-row"><button type="button" class="pf-pv-btn">' + esc(t('pv_btn')) + '</button><span class="pf-pv-link">' + esc(t('pv_link')) + '</span></div>' +
      '</div></div>' +
      '<div class="pf-sub">' + esc(t('typography')) + '</div>' +
      '<div class="pf-typo"><div><small>' + esc(t('heading_font')) + '</small><div class="aa" style="font-family:\'' + fh + '\',sans-serif;color:' + hex(c.primary, '#818cf8') + '">Aa</div><b>' + esc(fh) + '</b></div>' +
      '<div><small>' + esc(t('body_font')) + '</small><div class="aa" style="font-family:\'' + fb + '\',sans-serif;color:#E8ECFF">Aa</div><b>' + esc(fb) + '</b></div></div>' +
      '<button type="button" class="pf-btn pf-export" data-export="' + i + '">' + esc(t('export')) + '</button>' +
    '</article>';
  }

  function renderResults(list) {
    schemes = list;
    results.innerHTML = list.map(renderScheme).join('');
    results.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault(); showErr('');
      var d = { name: form.name.value.trim(), industry: form.industry.value.trim(), mood: form.mood.value.trim(), stack: form.stack.value.trim(), country: form.country.value.trim() };
      var bad = false;
      ['name', 'industry', 'mood'].forEach(function (k) { var el = form[k]; var inv = !d[k]; el.classList.toggle('is-invalid', inv); if (inv) bad = true; });
      if (bad) { showErr(t('err_fields')); return; }

      var btn = $('#pf-submit'), lab = $('.pf-btn-label', btn);
      btn.disabled = true; lab.removeAttribute('data-i18n'); lab.textContent = t('btn_working');
      results.innerHTML = ''; loading.hidden = false;
      post('palettify_generate_design', d).then(function (r) {
        if (r && r.success && r.data.schemes) renderResults(r.data.schemes);
        else showErr((r && r.data && r.data.message) || t('err_generic'));
      }).catch(function () { showErr(t('err_generic')); }).then(function () {
        loading.hidden = true; btn.disabled = false; lab.setAttribute('data-i18n', 'btn_generate'); lab.textContent = t('btn_generate');
      });
    });
    form.addEventListener('input', function (e) { e.target.classList.remove('is-invalid'); });
  }

  /* copy HEX + export */
  var modal = $('#pf-modal'), exportText = $('#pf-export-text'), exportTab = 'css', exportIdx = 0;
  function buildExport(i, tab) {
    var s = schemes[i]; if (!s) return '';
    var c = s.colors, f = s.fonts, fh = fam(f.heading), fb = fam(f.body);
    if (tab === 'css') {
      return '/* ' + s.title + ' — generated by Palettify.ai */\n@import url("https://fonts.googleapis.com/css2?family=' + fh.replace(/ /g, '+') + ':wght@400;600;700&family=' + fb.replace(/ /g, '+') + ':wght@400;500;600&display=swap");\n\n:root {\n' +
        '  --color-background: ' + c.background + ';\n  --color-primary: ' + c.primary + ';\n  --color-heading: ' + c.heading + ';\n  --color-body: ' + c.body + ';\n  --color-button-bg: ' + c.button_bg + ';\n  --color-button-text: ' + c.button_text + ';\n' +
        '  --font-heading: "' + fh + '", sans-serif;\n  --font-body: "' + fb + '", sans-serif;\n}\n\nbody { background: var(--color-background); color: var(--color-body); font-family: var(--font-body); }\nh1, h2, h3 { color: var(--color-heading); font-family: var(--font-heading); }\n.btn { background: var(--color-button-bg); color: var(--color-button-text); }';
    }
    return '// tailwind.config.js — ' + s.title + ' (Palettify.ai)\nmodule.exports = {\n  theme: {\n    extend: {\n      colors: {\n        brand: {\n' +
      "          background: '" + c.background + "',\n          primary: '" + c.primary + "',\n          heading: '" + c.heading + "',\n          body: '" + c.body + "',\n          'button-bg': '" + c.button_bg + "',\n          'button-text': '" + c.button_text + "',\n        },\n      },\n" +
      "      fontFamily: {\n        heading: ['\"" + fh + "\"', 'sans-serif'],\n        body: ['\"" + fb + "\"', 'sans-serif'],\n      },\n    },\n  },\n};\n";
  }
  function openExport(i) { exportIdx = i; exportTab = 'css'; $$('.pf-tabs button').forEach(function (b) { b.classList.toggle('is-active', b.dataset.tab === 'css'); }); exportText.value = buildExport(i, 'css'); modal.hidden = false; }

  document.addEventListener('click', function (e) {
    var sw = e.target.closest('.pf-sw');
    if (sw) {
      copyText(sw.dataset.hex).then(function () {
        var tag = $('[data-copy]', sw); sw.classList.add('is-copied'); tag.textContent = t('copied');
        setTimeout(function () { sw.classList.remove('is-copied'); tag.textContent = t('copy_hex'); }, 1400);
      }); return;
    }
    var ex = e.target.closest('[data-export]'); if (ex) { openExport(+ex.dataset.export); return; }
    var tb = e.target.closest('.pf-tabs button');
    if (tb) { exportTab = tb.dataset.tab; $$('.pf-tabs button').forEach(function (b) { b.classList.toggle('is-active', b === tb); }); exportText.value = buildExport(exportIdx, exportTab); return; }
    if (e.target.id === 'pf-modal-close' || e.target === modal) modal.hidden = true;
    if (e.target.id === 'pf-export-copy') {
      var b = e.target; copyText(exportText.value).then(function () { b.removeAttribute('data-i18n'); b.textContent = t('copied'); setTimeout(function () { b.setAttribute('data-i18n', 'copy_code'); b.textContent = t('copy_code'); }, 1400); });
    }
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { if (modal) modal.hidden = true; closeChat(); } });

  /* ================= chatbot ================= */
  var chat = $('#pf-chat'), fab = $('#pf-chat-fab'), panel = $('#pf-chat-panel'), log = $('#pf-chat-log'),
      cform = $('#pf-chat-form'), cinput = $('#pf-chat-input'), chips = $('#pf-chat-chips');
  var history = [], busy = false;

  function md(s) {
    var h = esc(s).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/`([^`]+)`/g, '<code>$1</code>');
    var lines = h.split(/\n/), out = '', inList = false;
    lines.forEach(function (ln) {
      var m = ln.match(/^\s*(?:[-*•]|\d+\.)\s+(.*)/);
      if (m) { if (!inList) { out += '<ul>'; inList = true; } out += '<li>' + m[1] + '</li>'; }
      else { if (inList) { out += '</ul>'; inList = false; } if (ln.trim()) out += '<p>' + ln + '</p>'; }
    });
    return out + (inList ? '</ul>' : '');
  }
  function addMsg(role, html, welcome) {
    var d = document.createElement('div'); d.className = 'pf-msg pf-msg-' + (role === 'user' ? 'user' : 'bot'); d.innerHTML = html;
    if (welcome) d.setAttribute('data-welcome', '1');
    log.appendChild(d); log.scrollTop = log.scrollHeight; return d;
  }
  function buildChips() {
    if (!chips) return;
    chips.innerHTML = '';
    [['chip1', 'chip_q1'], ['chip2', 'chip_q2'], ['chip3', 'chip_q3']].forEach(function (p) {
      var b = document.createElement('button'); b.type = 'button'; b.textContent = t(p[0]);
      b.addEventListener('click', function () { send(t(p[1])); }); chips.appendChild(b);
    });
  }
  function openChat() { chat.classList.add('is-open'); panel.hidden = false; fab.setAttribute('aria-expanded', 'true'); setTimeout(function () { cinput.focus(); }, 200); }
  function closeChat() { if (!chat) return; chat.classList.remove('is-open'); panel.hidden = true; fab.setAttribute('aria-expanded', 'false'); }
  function send(text) {
    text = (text || '').trim(); if (!text || busy) return;
    busy = true; chips.style.display = 'none';
    addMsg('user', '<p>' + esc(text) + '</p>'); cinput.value = '';
    var typing = addMsg('bot', '<div class="pf-typing"><i></i><i></i><i></i></div>');
    post('palettify_ai_chat', { message: text, history: JSON.stringify(history) }).then(function (r) {
      var reply = r && r.success ? r.data.reply : ((r && r.data && r.data.message) || t('chat_err'));
      typing.innerHTML = md(reply);
      if (r && r.success) { history.push({ role: 'user', content: text }, { role: 'assistant', content: reply }); history = history.slice(-10); }
    }).catch(function () { typing.innerHTML = '<p>' + esc(t('chat_err')) + '</p>'; })
      .then(function () { busy = false; log.scrollTop = log.scrollHeight; });
  }
  if (chat) {
    fab.addEventListener('click', function () { chat.classList.contains('is-open') ? closeChat() : openChat(); });
    cform.addEventListener('submit', function (e) { e.preventDefault(); send(cinput.value); });
    addMsg('bot', '<p>' + esc(t('chat_welcome')) + '</p>', true);
  }

  applyLang();
})();
